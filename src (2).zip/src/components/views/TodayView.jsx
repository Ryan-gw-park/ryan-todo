import { useState, useRef, useEffect, useCallback, useMemo } from 'react'
import { COLOR, FONT, SPACE, VIEW_WIDTH } from '../../styles/designTokens'
import {
  DndContext, DragOverlay, useDroppable,
  PointerSensor, TouchSensor, useSensors, useSensor, closestCenter,
} from '@dnd-kit/core'
import {
  SortableContext, useSortable, verticalListSortingStrategy, arrayMove,
} from '@dnd-kit/sortable'
import useStore from '../../hooks/useStore'
import { getColor } from '../../utils/colors'
import { CheckIcon } from '../shared/Icons'
import { parseDateFromText } from '../../utils/dateParser'
import { getNextAlarmTime } from '../../utils/alarm'
// ProjectFilter removed — scope determined by sidebar (Loop-39)
import useProjectFilter from '../../hooks/useProjectFilter'
import UniversalCard from '../common/UniversalCard'
import MSBadge from '../common/MSBadge'

const HIGHLIGHT_COLORS = {
  red:    { bg: '#E53E3E' },
  orange: { bg: '#DD6B20' },
  yellow: { bg: '#D69E2E' },
  blue:   { bg: '#3182CE' },
  green:  { bg: '#38A169' },
  purple: { bg: '#805AD5' },
}

export default function TodayView() {
  const { projects, tasks, moveTaskTo, reorderTasks, collapseState, toggleCollapse, setCollapseGroup } = useStore()
  const { filteredProjects, filteredTasks } = useProjectFilter(projects, tasks)
  const isMobile = window.innerWidth < 768

  const [activeId, setActiveId] = useState(null)
  const [showMs, setShowMs] = useState(false)
  const milestones = useStore(s => s.milestones)
  const msMap = useMemo(() => {
    const m = {}
    milestones.forEach(ms => { m[ms.id] = ms })
    return m
  }, [milestones])
  const collapsed = collapseState.today || {}
  const allCollapsed = filteredProjects.every(p => collapsed[p.id])

  const toggleAll = () => {
    const newState = {}
    filteredProjects.forEach(p => { newState[p.id] = !allCollapsed })
    setCollapseGroup('today', newState)
  }
  const toggleProject = (pid) => toggleCollapse('today', pid)

  const pointerSensor = useSensor(PointerSensor, { activationConstraint: { distance: 3 } })
  const touchSensor = useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 5 } })
  const sensors = useSensors(pointerSensor, touchSensor)

  /* Auto-focus first input on keyboard tab switch */
  useEffect(() => {
    const handler = () => {
      setTimeout(() => {
        const el = document.querySelector('[data-view="today"] input[type="text"], [data-view="today"] input:not([type])')
        el?.focus()
      }, 50)
    }
    window.addEventListener('view-focus', handler)
    return () => window.removeEventListener('view-focus', handler)
  }, [])

  const greetingEmoji = () => { const h = new Date().getHours(); return h < 12 ? '☀️' : h < 18 ? '🌤' : '🌙' }
  const dd = new Date()
  const dateStr = `${dd.getFullYear()}년 ${dd.getMonth()+1}월 ${dd.getDate()}일 ${['일','월','화','수','목','금','토'][dd.getDay()]}요일`

  const todayAlarms = useMemo(() => {
    const todayEnd = new Date()
    todayEnd.setHours(23, 59, 59, 999)
    return tasks
      .filter((t) => {
        if (!t.alarm?.enabled) return false
        const next = getNextAlarmTime(t.alarm)
        return next && next <= todayEnd
      })
      .sort((a, b) => {
        const ta = getNextAlarmTime(a.alarm)
        const tb = getNextAlarmTime(b.alarm)
        return ta - tb
      })
  }, [tasks])

  const activeTask = activeId ? tasks.find(t => t.id === activeId) : null

  const handleDragStart = (e) => setActiveId(e.active.id)

  const handleDragEnd = (e) => {
    setActiveId(null)
    const { active, over } = e
    if (!over) return

    const task = tasks.find(t => t.id === active.id)
    if (!task) return

    const overId = over.id

    // Dropped on a project drop zone
    if (typeof overId === 'string' && overId.startsWith('project:')) {
      const targetProjectId = overId.replace('project:', '')
      if (task.projectId !== targetProjectId) {
        const targetTasks = tasks
          .filter(t => t.projectId === targetProjectId && t.category === 'today' && !t.done)
          .sort((a, b) => a.sortOrder - b.sortOrder)
        const newOrder = targetTasks.length > 0 ? targetTasks[targetTasks.length - 1].sortOrder + 1 : Date.now()
        moveTaskTo(active.id, targetProjectId, 'today')
        useStore.getState().updateTask(active.id, { sortOrder: newOrder })
      }
      return
    }

    // Dropped on another task
    const overTask = tasks.find(t => t.id === overId)
    if (!overTask) return

    if (task.projectId === overTask.projectId) {
      // Same project: reorder
      const projectTasks = tasks
        .filter(t => t.projectId === task.projectId && t.category === 'today' && !t.done)
        .sort((a, b) => a.sortOrder - b.sortOrder)
      const oldIndex = projectTasks.findIndex(t => t.id === active.id)
      const newIndex = projectTasks.findIndex(t => t.id === overId)
      if (oldIndex !== -1 && newIndex !== -1 && oldIndex !== newIndex) {
        reorderTasks(arrayMove(projectTasks, oldIndex, newIndex))
      }
    } else {
      // Cross-project move
      const targetProjectId = overTask.projectId
      const targetTasks = tasks
        .filter(t => t.projectId === targetProjectId && t.category === 'today' && !t.done)
        .sort((a, b) => a.sortOrder - b.sortOrder)
      const overIndex = targetTasks.findIndex(t => t.id === overId)
      moveTaskTo(active.id, targetProjectId, 'today')
      const newList = [...targetTasks]
      newList.splice(overIndex, 0, { ...task, projectId: targetProjectId })
      reorderTasks(newList)
    }
  }

  return (
    <div data-view="today" style={{ padding: isMobile ? SPACE.viewPaddingMobile : SPACE.viewPadding }}>
      <div style={{ maxWidth: VIEW_WIDTH.narrow, margin: '0 auto' }}>
        <div className="today-header" style={{ marginBottom: 32, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div className="today-greeting">
            <h1 style={{ fontSize: FONT.viewTitle, fontWeight: 700, color: COLOR.textPrimary, margin: 0 }}>{greetingEmoji()} 좋은 하루 되세요, Ryan</h1>
            <p style={{ fontSize: FONT.subtitle, color: COLOR.textTertiary, marginTop: 4 }}>{dateStr}</p>
          </div>
          <div className="today-toolbar" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: FONT.label, color: COLOR.textTertiary, cursor: 'pointer', whiteSpace: 'nowrap', userSelect: 'none' }}>
              <input type="checkbox" checked={showMs} onChange={e => setShowMs(e.target.checked)} style={{ margin: 0 }} />
              MS
            </label>
            <button
            onClick={toggleAll}
            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: FONT.label, color: COLOR.textTertiary, fontFamily: 'inherit', padding: '4px 0', whiteSpace: 'nowrap' }}
            onMouseEnter={e => e.currentTarget.style.color = COLOR.textPrimary}
            onMouseLeave={e => e.currentTarget.style.color = COLOR.textTertiary}
          >
            {allCollapsed ? '전체 펼치기' : '전체 접기'}
          </button>
          </div>
        </div>
        {todayAlarms.length > 0 && (
          <div style={{ marginBottom: 20, padding: '14px 16px', background: '#fffdf5', borderRadius: 10, border: '1px solid rgba(0,0,0,0.06)' }}>
            <div style={{ fontSize: FONT.body, fontWeight: 600, color: COLOR.textPrimary, marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
              <span>🔔</span> 오늘 예정된 알람
            </div>
            {todayAlarms.map((task) => {
              const next = getNextAlarmTime(task.alarm)
              return (
                <div key={task.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 0', fontSize: 13 }}>
                  <span style={{ color: '#e8a735', fontWeight: 600, fontSize: 12, minWidth: 52 }}>
                    {next.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                  <span style={{ color: '#37352f' }}>{task.text}</span>
                </div>
              )
            })}
          </div>
        )}

        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
          <div style={{ display: 'grid', gridTemplateColumns: isMobile ? '1fr' : 'repeat(2, 1fr)', gap: 16 }}>
            {filteredProjects.map(p => {
              const c = getColor(p.color)
              const todayTasks = tasks
                .filter(t => t.projectId === p.id && t.category === 'today' && !t.done)
                .sort((a, b) => a.sortOrder - b.sortOrder)
              return (
                <ProjectCard key={p.id} project={p} color={c} todayTasks={todayTasks} activeId={activeId} isCollapsed={collapsed[p.id]} onToggleCollapse={() => toggleProject(p.id)} showMs={showMs} msMap={msMap} />
              )
            })}
          </div>

          <DragOverlay dropAnimation={null}>
            {activeTask ? <TaskOverlay task={activeTask} /> : null}
          </DragOverlay>
        </DndContext>
      </div>
    </div>
  )
}

/* ─── Project card with drop zone ─── */
function ProjectCard({ project, color, todayTasks, activeId, isCollapsed, onToggleCollapse, showMs, msMap }) {
  const { isOver, setNodeRef } = useDroppable({ id: `project:${project.id}` })
  const showHighlight = isOver && activeId
  const isMobile = window.innerWidth < 768
  const isEmpty = todayTasks.length === 0

  const [expandedIds, setExpandedIds] = useState(new Set())
  const toggleExpand = useCallback((id) => {
    setExpandedIds(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }, [])

  return (
    <div ref={setNodeRef} style={{
      background: color.card, borderRadius: 10, overflow: 'hidden',
      border: showHighlight ? `2px dashed ${color.dot}` : '1px solid rgba(0,0,0,0.04)',
      transition: 'border 0.15s, background 0.15s',
      ...(showHighlight ? { background: color.header } : {}),
    }}>
      <div style={{ background: color.header, padding: isEmpty ? '10px 16px' : '12px 16px', display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }} onClick={onToggleCollapse}>
        <div style={{ width: 10, height: 10, borderRadius: 3, background: color.dot }} />
        <span style={{ fontSize: isMobile ? FONT.subtitle : FONT.sectionTitle, fontWeight: 600, color: color.text }}>{project.name}</span>
        <span style={{ fontSize: FONT.caption, color: color.text, background: 'rgba(255,255,255,0.6)', borderRadius: 10, padding: '2px 8px', fontWeight: 600, marginLeft: 'auto' }}>{todayTasks.length}</span>
        {isEmpty && <InlineAddSimple projectId={project.id} color={color} compact />}
        {!isEmpty && <span style={{ color: color.text, opacity: 0.5, fontSize: FONT.label, transition: 'transform 0.15s', transform: isCollapsed ? 'rotate(-90deg)' : 'rotate(0deg)' }}>▾</span>}
      </div>
      {!isCollapsed && !isEmpty && (
        <div style={{ padding: '10px 16px' }}>
          <SortableContext items={todayTasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
            {todayTasks.map(tk => (
              <SortableTaskItem
                key={tk.id}
                task={tk}
                expanded={expandedIds.has(tk.id)}
                onToggleExpand={() => toggleExpand(tk.id)}
                showMs={showMs}
                msMap={msMap}
              />
            ))}
            <InlineAddSimple projectId={project.id} color={color} />
          </SortableContext>
        </div>
      )}
    </div>
  )
}

/* ─── Sortable task item using UniversalCard ─── */
function SortableTaskItem({ task, expanded, onToggleExpand, showMs, msMap }) {
  const { toggleDone, updateTask, openDetail } = useStore()
  const isMobile = window.innerWidth < 768
  const {
    attributes, listeners, setNodeRef, transform, transition, isDragging,
  } = useSortable({ id: task.id })

  // ★ Loop-21: Highlight color
  const hlColorKey = useStore.getState().getHighlightColor(task.id)
  const hlColor = hlColorKey && HIGHLIGHT_COLORS[hlColorKey]

  const handleTitleSave = useCallback((text) => {
    const { startDate, dueDate } = parseDateFromText(text)
    const patch = { text }
    if (startDate) patch.startDate = startDate
    if (dueDate) patch.dueDate = dueDate
    updateTask(task.id, patch)
  }, [task.id, updateTask])

  return (
    <UniversalCard
      type="task"
      data={{ id: task.id, name: task.text, done: false }}
      expanded={expanded}
      onToggleExpand={onToggleExpand}
      onTitleSave={handleTitleSave}
      onStatusToggle={() => toggleDone(task.id)}
      onDetailOpen={() => openDetail(task)}
      dragRef={setNodeRef}
      dragStyle={{
        transition: transition || undefined,
        transform: transform ? `translate3d(${transform.x}px, ${transform.y}px, 0)` : undefined,
      }}
      dragListeners={!isMobile ? listeners : undefined}
      dragAttributes={attributes}
      isDragging={isDragging}
      style={{
        marginBottom: 1, borderRadius: 6,
        ...(hlColor ? { background: hlColor.bg, color: '#fff' } : {}),
      }}
      renderMeta={showMs && task.keyMilestoneId && msMap[task.keyMilestoneId] ? () => <MSBadge milestone={msMap[task.keyMilestoneId]} /> : undefined}
      renderExpanded={task.notes ? () => (
        <div style={{ fontSize: FONT.label, color: COLOR.textSecondary, lineHeight: 1.4 }}>
          {task.notes.length > 100 ? task.notes.slice(0, 100) + '…' : task.notes}
        </div>
      ) : undefined}
    />
  )
}

/* ─── Inline add (simplified for Today view) ─── */
function InlineAddSimple({ projectId, color, compact }) {
  const { addTask } = useStore()
  const [active, setActive] = useState(false)
  const [text, setText] = useState('')
  const ref = useRef(null)

  useEffect(() => { if (active && ref.current) ref.current.focus() }, [active])

  const handleAdd = () => {
    if (!text.trim()) return
    const { startDate, dueDate } = parseDateFromText(text.trim())
    addTask({ text: text.trim(), projectId, category: 'today', startDate, dueDate })
    setText('')
  }

  if (!active) {
    return (
      <button
        onClick={(e) => { e.stopPropagation(); setActive(true); setText('') }}
        style={compact
          ? { background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,0.6)', fontSize: FONT.label, fontFamily: 'inherit', padding: '2px 6px', whiteSpace: 'nowrap', borderRadius: 4, transition: 'color 0.15s' }
          : { display: 'flex', alignItems: 'center', gap: 5, padding: '4px 4px', background: 'none', border: 'none', cursor: 'pointer', color: '#c8c8c8', fontSize: FONT.label, width: '100%', borderRadius: 4, transition: 'all 0.15s', fontFamily: 'inherit' }
        }
        onMouseEnter={e => { e.currentTarget.style.color = compact ? '#fff' : color.text; if (!compact) e.currentTarget.style.background = 'rgba(0,0,0,0.03)' }}
        onMouseLeave={e => { e.currentTarget.style.color = compact ? 'rgba(255,255,255,0.6)' : '#c8c8c8'; if (!compact) e.currentTarget.style.background = 'none' }}
      >
        + 추가
      </button>
    )
  }

  return (
    <div style={{ padding: compact ? '0' : '4px 0' }} onClick={e => e.stopPropagation()}>
      <input
        ref={ref} value={text} onChange={e => setText(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') handleAdd(); if (e.key === 'Escape') setActive(false) }}
        onBlur={() => { if (!text.trim()) setActive(false) }}
        placeholder="할일을 입력하세요..."
        style={{ width: compact ? 140 : '100%', padding: '6px 8px', fontSize: FONT.body, border: `1.5px solid ${color.dot}`, borderRadius: 6, outline: 'none', background: 'white', fontFamily: 'inherit', boxSizing: 'border-box' }}
      />
    </div>
  )
}

/* ─── Mobile context menu ─── */
/* ─── Drag overlay card ─── */
function TaskOverlay({ task }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-start', gap: 8,
      padding: '8px 12px', borderRadius: 8, background: 'white',
      boxShadow: '0 8px 24px rgba(0,0,0,0.15)', border: '1px solid rgba(0,0,0,0.06)',
      transform: 'rotate(2deg)', cursor: 'grabbing', maxWidth: 350,
    }}>
      <div style={{ paddingTop: 1, flexShrink: 0 }}>
        <CheckIcon checked={false} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, lineHeight: '19px', color: '#37352f' }}>{task.text}</div>
        {task.dueDate && <div style={{ fontSize: 11, color: '#bbb', marginTop: 1 }}>{task.dueDate}</div>}
      </div>
    </div>
  )
}
